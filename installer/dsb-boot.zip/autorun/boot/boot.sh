#!/bin/sh
# HS Boot session (setsid from autorun.sh, runs from /tmp/hs-boot). Stops stock, shows the menu,
# runs the chosen entry's start script and comes back to the menu when it exits.
# An entry counts as crashed until it has run HEALTHY seconds; two crashes in a row of the same
# entry make Stock the menu's default (hsboot reads and writes the count in hs-boot.state).
#
# Start script contract (autorun/os/<name>/os.json "start"):
#   run with sh, in the foreground, for as long as that OS runs. Environment:
#   HSBOOT_DIR = the card's autorun folder, HSBOOT_OS_DIR = the entry's folder (empty for built-ins),
#   HSBOOT_STOCK = the stock app binary. Exit 100 = "I started stock (ac50.service), boot is done".
#   Exit 101 = the same after a crash: boot is done, and the start stays counted as a crash.
#   Exit 102 = "the user left me on purpose (SHIFT+STOP)": stock was NOT started, not a crash; the menu comes
#   back and waits (no 5 s auto-start, so the OS just quit is not relaunched behind the user's back).
# OSes with no way out of their own (an "autorun" entry, HS FX) get hs-menukey.so first in LD_PRELOAD: SHIFT+STOP held
# 2 s runs back.sh, which stops the OS and brings this menu back (HSBOOT_BACK=1 = started again by back.sh: no auto-start).
#
# D.S.B Boot: the menu is hsrecords (the graphical picker) when the card ships it, else (or if it fails) hsboot's
# text menu. An entry of kind "autorun" is an OS's unchanged release autorun folder (os/<name>/autorun.json):
# run as the firmware (and SampleBoot, MIT, Paxi / pxcm: boot/NOTICE.txt) would run it: sh <its script> as root
# from / (never a folder on the card: SD Card Access needs the card free); when that returns, an app must be up within GRACE s, else stock starts and the start stays
# counted as a crash. Its files carry no pins (they are the user's own copy of that OS's release).
cd /                                            # nothing we start may hold the card (SD Card Access)
DIR="$1"
FW="$2"                                         # sha256 of the stock app this card was tested on
RUN=/tmp/hs-boot
HSBOOT="$RUN/hsboot"
STATE="$DIR/hs-boot.state"
STOCK="${HSBOOT_STOCK_BIN:-/usr/bin/MPC Sample}"   # override: build-host dry run only
HEALTHY=120
GRACE=${HSBOOT_GRACE:-60}                       # s a third-party OS gets to bring its app up (override: checks only)
SETTLE=${HSBOOT_SETTLE:-15}                     # s before "an app is up" is believed (SampleBoot's 15 s)
ROOT_FILES="mpcqol.conf"                        # card-root files an OS reads from "the folder above its own"
WATCH_PROCS="MPC Sample|sample-base|mpcsimple"

log() { echo "$(date '+%F %T') $*"; }
stock() { log "-> stock ($1)"; systemctl start ac50.service; exit 0; }

# An app is up: the stock unit is active, a process holds the surface MIDI port, or a known app process runs.
alive() {
    [ -n "$QOL" ] && { qol_up; return; }        # SampQOL OS: only its own app counts (see sampqol below)
    systemctl is-active --quiet ac50.service 2>/dev/null && { WHY="ac50.service active"; return 0; }
    WHO=$("$HSBOOT" surface-busy 2>/dev/null) && { WHY="surface port held by $WHO"; return 0; }
    for c in /proc/[0-9]*/comm; do
        { read -r P < "$c"; } 2>/dev/null || continue
        case "|$WATCH_PROCS|" in *"|$P|"*) WHY="process $P"; return 0 ;; esac
    done
    return 1
}

# An OS's own release autorun folder ($1 = folder, $2 = its start script): SampleBoot's way. Returns 0 when its
# app is up (boot is done), 1 when none came up (the caller starts stock; the crash stays counted).
run_autorun() {
    M="$1"; S="${2#"$1"/}"; CARD=${DIR%/*}
    for f in $ROOT_FILES; do                    # card-root settings copied into os/, where the OS looks for them
        [ -f "$CARD/$f" ] || continue
        # a copy, not a bind mount: a mount inside the card keeps it busy and SD Card Access then fails.
        # ponytail: the root copy wins only when it is newer; the OS saves into os/ after that.
        { [ -f "$DIR/os/$f" ] && [ ! "$CARD/$f" -nt "$DIR/os/$f" ]; } && continue
        cp "$CARD/$f" "$DIR/os/$f" 2>/dev/null && log "$f: card root's file copied to os/" ||
            log "$f: could not copy the card root's file to os/"
    done
    if [ -e "$M/sampleboot.inplace" ]; then     # the OS takes "the folder above its own" for the card: run it from autorun/
        # our state file is under autorun/: keep a view of it before the OS's folder covers autorun/
        if mkdir -p /run/hs-boot/autorun && mount --bind "$DIR" /run/hs-boot/autorun 2>/dev/null; then
            if mount --bind "$M" "$DIR" 2>/dev/null; then
                STATE=/run/hs-boot/autorun/hs-boot.state; M="$DIR"; log "$ID runs from autorun/ (sampleboot.inplace)"
            else
                umount /run/hs-boot/autorun 2>/dev/null; log "$ID: could not bind it over autorun/: runs from its folder"
            fi
        else log "$ID: could not keep a view of autorun/: runs from its folder"; fi
    fi
    log "-> $ID: sh $M/$S"
    # from / as the firmware's own runner does: a working folder on the card is inherited by the app and
    # keeps the card busy, so SD Card Access fails ("SD card is busy"). Its script finds its folder from $0.
    (cd / && HSBOOT_MENUKEY="$MENUKEY" LD_PRELOAD="$MENUKEY${MENUKEY:+${LD_PRELOAD:+:}}$LD_PRELOAD" sh "$M/$S")
    log "$ID: its autorun returned $?: waiting for its app"
    i=0
    while [ "$i" -lt "$GRACE" ]; do
        sleep 1; i=$((i + 1))
        [ "$i" -ge "$SETTLE" ] && alive && { log "$ID: app up after ${i}s ($WHY)"; return 0; }
    done
    alive && { log "$ID: app up ($WHY)"; return 0; }
    log "$ID: no app after ${GRACE}s"
    return 1
}

# SampQOL OS (github.com/snarebes/sampqol-os, "SampQOL-interface-for-HS.md" from its author) is an "autorun" entry
# that the files themselves identify, never the folder name: autorun.json names autorun.sh, and autorun.sh has a
# PINS="..." block that lists qol-run.sh and mpcqol.so. Older releases give no pin-failure message,
# so the same check runs here first ($1 = folder, $2 = start script): bad or missing files give a message on the
# screen for MSGWAIT s, then this menu again, waiting for a pick (no auto-start, no stock, not a GRACE wait). Any version: the format is stable and its own pins + firmware check gate it.
# A folder without that PINS block (any other OS, also one that ships an mpcqol.so) leaves QOL empty and takes
# the plain autorun path, unchanged.
# Its qol-run.sh sets LD_PRELOAD itself and drops ours, so hs-menukey.so (SHIFT+STOP) is not in the SampQOL app.
# Return to this menu (SampQOL's MENU-RETURN-PROTOCOL.md, part B; works once SampQOL adds part A, not in 0.3.0/0.4.0,
# which read neither file): before SampQOL starts, /run/qol-run.menu names back.sh, which SampQOL then runs on
# SHIFT+STOP held 2 s; back.sh writes /run/qol-run.stop so its watchdog ends without a restart or stock.
QOL=
MSGWAIT=${HSBOOT_MSGWAIT:-8}                    # s a SampQOL message stays up before the menu (override: checks only)
QOLPID=/run/qol-run.pid                         # its watchdog (qol-run.sh) writes its pid here
qol_fail() {                                    # $1 = what is wrong: on the screen, in the log; returns 1 (the menu)
    "$HSBOOT" splash "" "$1" "Copy the release folder again" 2>/dev/null
    sleep "$MSGWAIT"
    log "$ID: $1: copy the release folder again: back to the menu"
    return 1
}
sampqol() {
    QOL=
    QP=$(awk '/^PINS="/ { f = 1; sub(/^PINS="/, "") }
              f { if (index($0, "\"")) { sub(/".*/, ""); print; exit } print }' "$1/autorun.sh" 2>/dev/null)
    if ! echo "$QP" | grep -q '^[0-9a-f]\{64\}  qol-run\.sh$' || ! echo "$QP" | grep -q '^[0-9a-f]\{64\}  mpcqol\.so$'; then
        [ -f "$1/mpcqol.so" ] && log "$ID: has mpcqol.so but no SampQOL PINS block: runs as a plain autorun folder"
        return 0                                # not SampQOL (or a build of it we do not know): the plain path
    fi
    if [ "${2##*/}" != autorun.sh ] || ! grep -q '"path"[[:space:]]*:[[:space:]]*"autorun.sh"' "$1/autorun.json" 2>/dev/null; then
        [ -f "$1/autorun.json" ] || { qol_fail "SampQOL files missing"; return 1; }
        qol_fail "Unknown SampQOL folder layout"; return 1
    fi
    for f in $(echo "$QP" | awk '{ print $2 }'); do [ -f "$1/$f" ] || { qol_fail "SampQOL files missing"; return 1; }; done
    (cd "$1" && echo "$QP" | sha256sum -c >/dev/null 2>&1) || { qol_fail "SampQOL files changed or damaged"; return 1; }
    V=$(grep -ao 'SampQOL OS [0-9][0-9.]* (c)' "$1/mpcqol.so" 2>/dev/null | head -n 1)
    V=${V#SampQOL OS }; V=${V% (c)}
    log "$ID: SampQOL OS ${V:-(no version string)}, its pins match"
    QOL=1
}
# Require both the watchdog and its loaded mod. The MPC renames its main thread during startup,
# and a plain stock app can be up while the watchdog is failing over.
qol_up() {
    { read -r Q < "$QOLPID"; } 2>/dev/null && [ -n "$Q" ] && grep -q qol-run "/proc/$Q/cmdline" 2>/dev/null || return 1
    for c in /proc/[0-9]*/comm; do
        { read -r P < "$c"; } 2>/dev/null || continue
        case "$P" in "MPC Sample"|"MPC Sample Main") ;; *) continue ;; esac
        grep -q ' /tmp/mpcqol\.so$' "${c%/comm}/maps" 2>/dev/null || continue
        WHY="MPC Sample + SampQOL watchdog $Q"
        return 0
    done
    return 1
}

# The menu's Stock pick only: stock opens the card's D.S.B Beat Template as a new, unsaved project. RAM only.
# The app reopens its last session from /data/TempProjects at start (its own --project option loaded nothing
# in the lab, with or without a session there). So this one start gets a RAM copy of the template as that session: a runtime
# drop-in (/run, gone at reboot, removed again once the app has started) bind-mounts $SESSION over
# /data/TempProjects in the app's own mount namespace. No original_project_data.txt = an untitled project, so
# Save asks for a name and the card file is never written. The unit's real session folder is never touched and
# comes back on the next plain start. Missing template, other firmware, or any failure: plain stock. Crash
# restarts and every other stock start stay plain.
TEMPLATE="HS-OS/Templates/D.S.B Beat Template"
SESSION="$RUN/stock-session"
UNITDIR="${HSBOOT_UNITDIR:-/run/systemd/system}"   # overrides: build-host dry run only
TEMPPROJECTS="${HSBOOT_TEMPPROJECTS:-/data/TempProjects}"
stock_template() {
    T="${DIR%/*}/$TEMPLATE"
    [ -f "$T.xpj" ] || stock "chosen, no template"
    [ -d "$TEMPPROJECTS" ] || stock "chosen, no $TEMPPROJECTS on this unit: no template"
    wait "$FWJOB" 2>/dev/null
    [ -n "$FW" ] && [ "$(cat "$RUN/fw" 2>/dev/null)" = "$FW" ] || stock "chosen, not the tested firmware: no template"
    rm -rf "$SESSION" && mkdir -p "$SESSION/Temp-Project_[ProjectData]" && cp "$T.xpj" "$SESSION/Temp-Project.xpj" &&
        { [ ! -d "${T}_[ProjectData]" ] || cp -R "${T}_[ProjectData]/." "$SESSION/Temp-Project_[ProjectData]/"; } ||
        stock "chosen, template copy failed"
    D="$UNITDIR/ac50.service.d"
    mkdir -p "$D" && printf '[Service]\nBindPaths=%s:%s\n' "$SESSION" "$TEMPPROJECTS" > "$D/hs-template.conf" &&
        systemctl daemon-reload || { rm -f "$D/hs-template.conf"; systemctl daemon-reload; stock "chosen, drop-in failed: no template"; }
    log "-> stock with template ($T.xpj)"
    systemctl start ac50.service; CODE=$?
    rm -f "$D/hs-template.conf"; rmdir "$D" 2>/dev/null
    systemctl daemon-reload                         # restarts from here on are plain stock
    if [ "$CODE" != 0 ] || ! systemctl is-active -q ac50.service; then
        systemctl reset-failed ac50.service 2>/dev/null; stock "template start failed"
    fi
    exit 0
}

[ -d "$DIR" ] && [ -x "$HSBOOT" ] || stock "missing $DIR or $HSBOOT"
echo $$ > /run/hs-boot/pid
printf '%s\n%s\n' "$DIR" "$FW" > /run/hs-boot/session    # for back.sh
rm -f /run/hs-boot/back
MENUKEY=                                        # SHIFT+STOP back to the menu, for OSes without their own way out
P=$(grep -E '  boot/(back\.sh|hs-menukey\.so)$' "$RUN/pins" 2>/dev/null)
if [ "$(echo "$P" | grep -c .)" = 2 ] && (cd "$DIR" && echo "$P" | sha256sum -c >/dev/null 2>&1) &&
   cp "$DIR/boot/back.sh" "$DIR/boot/hs-menukey.so" "$RUN/" && chmod 644 "$RUN/hs-menukey.so" &&
   (cd "$RUN" && echo "$P" | sed "s#  boot/#  #" | sha256sum -c >/dev/null 2>&1); then
    MENUKEY="$RUN/hs-menukey.so"
else
    log "no SHIFT+STOP menu key (back.sh / hs-menukey.so missing or not matching their pins)"
fi
# Stock off the glass first, then everything slow happens behind the HS screens.
systemctl stop ac50.service 2>/dev/null         # returns once the app has exited
killall -9 -q "MPC Sample" 2>/dev/null          # anything the stop left behind
# ponytail: firmware check runs beside the menu (the whole binary, ~seconds on this CPU); read after a pick
( sha256sum "$STOCK" 2>/dev/null | cut -d' ' -f1 > "$RUN/fw" ) &
FWJOB=$!

BACK=${HSBOOT_BACK:-}                           # 1 = the menu is back after a deliberate exit: wait for a pick
while :; do
    # ponytail: tmpfs log, emptied past 256 KB (appended to, so truncating in place is safe)
    [ "$(wc -c < /run/hs-boot/boot.log 2>/dev/null || echo 0)" -gt 262144 ] && : > /run/hs-boot/boot.log
    MENU=1
    [ -x "$RUN/hsrecords" ] && { HSBOOT_NOAUTO="$BACK" "$RUN/hsrecords" pick "$DIR" "$STATE" > "$RUN/choice"; MENU=$?; }
    if [ "$MENU" = 3 ]; then                    # the power key + Yes on the menu: nothing is running, so just power off
        log "power off from the menu"
        "$HSBOOT" splash "" "Shutting down" 2>/dev/null
        sync; poweroff; exit 0
    fi
    if [ "$MENU" = 0 ]; then :
    else
        [ -x "$RUN/hsrecords" ] && log "record menu failed: text menu"
        HSBOOT_NOAUTO="$BACK" "$HSBOOT" pick "$DIR" "$STATE" > "$RUN/choice" || stock "menu exit $?"
    fi
    BACK=
    { IFS= read -r ID; IFS= read -r START; IFS= read -r OSDIR; IFS= read -r KIND; } < "$RUN/choice"
    [ -n "$ID" ] || stock "no choice"
    "$HSBOOT" started "$STATE" "$ID" || log "boot state not saved"
    [ "$ID" = stock ] && stock_template
    # the "Loading" screen is up (hsboot drew it): check this OS behind it
    wait "$FWJOB" 2>/dev/null
    [ -n "$FW" ] && [ "$(cat "$RUN/fw" 2>/dev/null)" = "$FW" ] || stock "stock app is not the tested firmware"
    if [ "$KIND" = autorun ]; then              # a third-party OS's own release: no pins (not ours to pin)
        "$HSBOOT" splash "$ID" "Loading" 2>/dev/null
        # SampQOL OS: its pins first. They fail: a message, then the menu waits (counted as a crash, as any failed start)
        sampqol "$OSDIR" "$START" || { BACK=1; continue; }
        rm -f /run/qol-run.menu /run/qol-run.stop   # nothing stale from an earlier start: the menu path only for SampQOL
        [ -n "$QOL" ] && [ -n "$MENUKEY" ] && echo "$RUN/back.sh" > /run/qol-run.menu   # back.sh is there with hs-menukey.so
        run_autorun "$OSDIR" "$START" && { "$HSBOOT" ok "$STATE" "$ID"; exit 0; }   # its app is up: not a crash
        stock "$ID started no app"
    fi
    P=$(awk -v a="  os/$ID/" -v b="  boot/$ID.sh" 'index($0, a) || substr($0, length($0) - length(b) + 1) == b' "$RUN/pins")
    [ -z "$P" ] || (cd "$DIR" && echo "$P" | sha256sum -c >/dev/null 2>&1) || stock "$ID files do not match their pins"

    log "-> $ID ($START)"
    ( sleep "$HEALTHY" && "$HSBOOT" ok "$STATE" "$ID" && log "$ID ran ${HEALTHY}s: healthy" ) &
    TIMER=$!
    # a RAM copy: a shell reading its script off the card holds it open, and SD Card Access then finds the card busy
    E="$RUN/entry.sh"; cp "$START" "$E" 2>/dev/null || E="$START"
    HSBOOT_DIR="$DIR" HSBOOT_OS_DIR="$OSDIR" HSBOOT_STOCK="$STOCK" HSBOOT_MENUKEY="$MENUKEY" sh "$E"
    CODE=$?
    kill "$TIMER" 2>/dev/null
    wait "$TIMER" 2>/dev/null

    [ "$(systemctl is-system-running 2>/dev/null)" = stopping ] && exit 0
    if [ "$CODE" = 100 ]; then
        "$HSBOOT" ok "$STATE" "$ID"             # a hand-over to stock is not a crash
        log "$ID handed over to stock"
        exit 0
    fi
    if [ "$CODE" = 102 ]; then
        "$HSBOOT" ok "$STATE" "$ID"             # a deliberate exit is not a crash
        log "$ID exited to the menu"
        BACK=1
        continue
    fi
    [ "$CODE" = 101 ] && { log "$ID crashed and handed over to stock"; exit 0; }
    log "$ID exited, code $CODE"
done
