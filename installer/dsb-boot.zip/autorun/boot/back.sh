#!/bin/sh
# Back to the D.S.B Boot menu: run by hs-menukey.so when SHIFT + STOP is held 2 s in an OS that has no way out of its own.
# boot.sh copies it to /tmp/hs-boot and writes /run/hs-boot/session (the card's autorun folder, the tested firmware).
# Two cases:
#   boot.sh still runs (a built-in entry, HS FX): flag + stop the app; its start script sees the flag and exits 102.
#   boot.sh has finished (an OS's own autorun folder: HS QOL, HS Tools, MPC Simple): stop that OS the way it stops
#   itself, then start boot.sh again with HSBOOT_BACK=1 (menu up, waiting for a pick, no auto-start).
# It runs in a scope of its own, so stopping the OS's service can't take this script down with it.
S=/run/hs-boot
RUN=/tmp/hs-boot
if [ -z "$HSBOOT_BACK_SCOPE" ] && command -v systemd-run >/dev/null 2>&1; then
    HSBOOT_BACK_SCOPE=1 exec systemd-run --scope --quiet --unit="hs-boot-back-$$" /bin/sh "$0" "$@" >> "$S/boot.log" 2>&1
fi
exec >> "$S/boot.log" 2>&1
log() { echo "$(date '+%F %T') back: $*"; }
{ IFS= read -r DIR; IFS= read -r FW; } < "$S/session" 2>/dev/null
[ -d "$DIR" ] || { log "no session: nothing to go back to"; exit 0; }
: > "$S/back"

running() { for n in "$@"; do pidof "$n" >/dev/null 2>&1 && return 0; done; return 1; }
script_running() {     # a shell running one of these scripts
    for c in /proc/[0-9]*/cmdline; do
        tr '\0' ' ' < "$c" 2>/dev/null | grep -qE "$1" && return 0
    done 2>/dev/null; return 1
}
wait_gone() {          # <seconds> <test...>: until the test fails or time runs out
    t=$1; shift; i=0
    while "$@" && [ "$i" -lt "$t" ]; do sleep 1; i=$((i + 1)); done
    ! "$@"
}

BOOT=$(cat "$S/pid" 2>/dev/null)
if [ -n "$BOOT" ] && tr '\0' ' ' < "/proc/$BOOT/cmdline" 2>/dev/null | grep -q 'hs-boot/boot.sh'; then
    log "SHIFT+STOP: closing the app, boot.sh brings the menu back"
    killall -TERM "MPC Sample" 2>/dev/null
    wait_gone 20 running "MPC Sample" || { log "app still up after 20 s: KILL"; killall -KILL "MPC Sample" 2>/dev/null; }
    exit 0
fi

log "SHIFT+STOP: closing the OS"
systemctl stop hs-tools.service 2>/dev/null &                      # HS Tools (Restart=always: stop, not kill)
for p in $(pidof sh 2>/dev/null); do                                # MPC Simple's launcher: its own EXIT trap tidies up
    tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null | grep -q 'launcher.sh' && kill -TERM "$p"
done
# SampQOL OS (a release folder): its watchdog ends for good, with no restart and no stock, when this file is there as
# the app exits (MENU-RETURN-PROTOCOL.md part B; works once SampQOL adds part A, not in 0.3.0/0.4.0, which ignore it)
[ -f /run/qol-run.pid ] && : > /run/qol-run.stop
killall -TERM mpcsimple "MPC Sample" 2>/dev/null                    # HS QOL's qol-run sees $S/back and stops looping
# done when the OS's own script has finished (qol-run after its snapshot sync, the launcher after its tidy-up).
# A stock app MPC Simple's tidy-up starts is boot.sh's to stop, so it is not waited for here.
qol_live() { Q=$(cat /run/qol-run.pid 2>/dev/null) && [ -n "$Q" ] && grep -q qol-run "/proc/$Q/cmdline" 2>/dev/null; }
osup() { running mpcsimple || script_running 'qol-run\.sh|launcher\.sh' || qol_live; }
if ! wait_gone 25 osup; then
    log "OS still up after 25 s: KILL"
    for p in $(pidof sh 2>/dev/null); do
        tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null | grep -qE 'qol-run\.sh|launcher\.sh' && kill -KILL "$p"
    done
    killall -KILL mpcsimple "MPC Sample" 2>/dev/null
fi
wait                                                                # hs-tools stopped
systemctl stop 'mpcsimple-guard-*' 2>/dev/null
rm -f /run/qol-run.pid /run/qol-run.stop
log "-> menu"
HSBOOT_BACK=1 exec sh "$RUN/boot.sh" "$DIR" "$FW"
