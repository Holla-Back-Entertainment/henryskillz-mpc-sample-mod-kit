#!/bin/sh
# Built-in HS FX entry (the free D.S.B Boot card): the stock app with the HS FX core preloaded, under
# setarch -R so the core's fixed hook addresses hold. Three HS effects join the stock Knob FX list:
# HS Para EQ, HS Tube Strip, HS Saturator. Nothing else from the HS AKAI core runs here.
#
# The card's autorun/hs-fx/ folder holds hs-fx.so (the core, built by build-hsfx.sh with -DHS_FX_FREE)
# and hs-fx-ladspa.so (the three effects); it is copied to /tmp/hs-fx (the card is noexec, and the core
# reads its library from /tmp/hs-fx only). Without both files: plain stock, exit 100.
# The core checks the app itself (build id, version note, the code it hooks); on any mismatch it logs to
# /run/hs-fx.log and leaves the app as stock.
#
# Exit codes (src/boot/boot.sh): 100 = stock started here. Otherwise the app's own exit code, as HS AKAI:
# SHIFT+STOP is the stock app's own; held 2 s, hs-menukey.so (HSBOOT_MENUKEY, from boot.sh) closes the app through
# back.sh and this exits 102: back to the menu, not a crash. A crash or kill returns to the menu, counted.
SRC="$HSBOOT_DIR/hs-fx"
RUN=/tmp/hs-fx
STOCK="${HSBOOT_STOCK:-/usr/bin/MPC Sample}"

rm -rf "$RUN"
if [ -f "$SRC/hs-fx.so" ] && [ -f "$SRC/hs-fx-ladspa.so" ] && mkdir -p "$RUN" &&
   cp "$SRC/hs-fx.so" "$SRC/hs-fx-ladspa.so" "$RUN/" && [ -f "$RUN/hs-fx.so" ] && [ -f "$RUN/hs-fx-ladspa.so" ]; then
    chmod 755 "$RUN"; chmod 644 "$RUN/hs-fx.so" "$RUN/hs-fx-ladspa.so"
else
    echo "hs-fx: no hs-fx.so / hs-fx-ladspa.so in $SRC: plain stock"
    rm -rf "$RUN"
    systemctl start ac50.service
    exit 100
fi

# The app's own output goes to app.log, fresh each start, so boot.log stays small. env sets LD_PRELOAD
# after setarch, so only the app loads the core (and the core unsets it for anything the app starts).
setarch -R -- env LD_PRELOAD="${HSBOOT_MENUKEY:+$HSBOOT_MENUKEY:}$RUN/hs-fx.so" "$STOCK" > /run/hs-boot/app.log 2>&1
CODE=$?
[ -e /run/hs-boot/back ] && { rm -f /run/hs-boot/back; echo "hs-fx: SHIFT+STOP: back to the menu"; exit 102; }
exit $CODE
