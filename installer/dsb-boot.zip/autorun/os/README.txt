D.S.B Boot: put each OS in its own folder here, os/<Folder>/.
Two kinds of folder work:
  1. An OS's release "autorun" folder, unchanged (it has autorun.json): copy the folder here and rename it.
     D.S.B Boot runs the script its autorun.json names, from its folder, as the MPC would.
  2. An HS Boot folder: os.json {"name": "My OS", "version": "1.0", "start": "start.sh"} + that script.
Optional, for the menu:
  dsb-record.png  square RGBA PNG, 128 x 128 recommended (16..1024 px, at most 1 MB); keep the art inside the
                  centred circle (90% of the width), transparent outside. Shown on the record / SD card sticker.
  dsb-cover.png   fit an existing rectangular PNG inside the label. You can also supply
                  autorun/boot/art/<Folder>.png for existing OS folders without editing them.
                  The menu tries the prepared label, cover, local art, then the OS's icon.png,
                  sampleboot.png or splash-screen.png. Entries without usable art show their name.
                  The card includes hardware photos for hs-20, hs-25, hs-30, hs-40 and hs-60.
  dsb-record.txt  line 1 = the name on the menu, line 2 = a small sub-line (for example the version).
                  Without it: sampleboot.txt line 1, else the folder name.
  sampleboot.inplace  (empty file) run the OS from autorun/ itself, for OSes that take "the folder above" for the card.
Folders sort by name, up to 37 show. "hs-akai", "hs-fx" and "stock" are reserved names.
