#!/bin/sh
# HS Boot (HS Sample OS part 1). The firmware's script runner starts this as root when the card
# mounts, and again whenever the stock app restarts. RAM-only: nothing on internal storage changes.
# Stock is killed first (it is what ran us, so it always paints first; this keeps it on the glass as short as
# possible). Any exit after that kill starts stock again, so a failed check never leaves a dead screen.
# make_card.py fills in PINS (sha256 of our own boot files) and signs autorun.check.
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUN=/tmp/hs-boot
STATE=/run/hs-boot
STOCK="/usr/bin/MPC Sample"
FW=b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508
PINS="c30c214f66e348dcbb182c381d933914119c6e2fff76108bfd7128523b222123  boot/boot.sh
e13bc9caec1f484e6ef9957a36b6c713a102e12a613ac8820a3c5643dd02b62e  boot/hsboot
6823e8ba096e1be02271b441ec86d9073b3236042ee0dd669238e52497c1d31b  boot/hsrecords
23b88aea551bb52f8b9d7b71a04dc0d78f55f7934d96ec34184d3b9a887bef2a  boot/hs-fx.sh
a5ddf2c268c0b16e653a7378b4e552533c824fb9a76360880faed707e62e6e73  boot/back.sh
d83070abffbcb5ba380a113c41a901bff6f6db3aa0316f052aa0abb8bbebcffc  boot/hs-menukey.so
0d1541619d36436a09af178c1f300d5c0196c8856ac29fb83b17a4afde27ab9f  hs-fx/hs-fx.so
38071cc30235e51291e7cd1950b2a897576789a27c1b5eefaad35c67c67144b2  hs-fx/hs-fx-ladspa.so"

[ "$(id -u)" = 0 ] || exit 0
[ -e "$STATE/started" ] && exit 0               # once per power-on (Stock restarts the runner)
# ponytail: the stock app runs this card's autorun itself, so it is already up before we can stop it.
# KILL skips its graceful-exit wait; stop is still needed because the unit has Restart=always (same order as Boot Thingy).
systemctl kill -s KILL ac50.service 2>/dev/null; systemctl stop ac50.service 2>/dev/null
stock() { echo "$*: stock restarted"; systemctl start ac50.service; exit 0; }
mkdir -p "$STATE" || stock "no $STATE"
: > "$STATE/started"
exec >> "$STATE/boot.log" 2>&1
echo "$(date '+%F %T') autorun from $DIR"

# Fast path, so stock is on the glass as briefly as possible: only the small boot files are checked
# here. boot.sh checks the stock firmware in the background while the menu is up, and each OS's own
# pins only when that OS is picked (pins handed over in $RUN/pins).
# D.S.B Boot cards also pin boot/hsrecords (the graphical menu): copied and checked with the other two.
BOOTFILES="boot.sh hsboot"
echo "$PINS" | grep -q '  boot/hsrecords$' && BOOTFILES="$BOOTFILES hsrecords"
mkdir -p "$RUN" && (cd "$DIR/boot" && cp $BOOTFILES "$RUN/") && chmod 755 "$RUN/hsboot" || {
    stock "copy to $RUN failed"; }
[ -f "$RUN/hsrecords" ] && chmod 755 "$RUN/hsrecords"
BOOTPINS=$(echo "$PINS" | grep -E '  boot/(boot\.sh|hsboot|hsrecords)$' | sed "s#  boot/#  $RUN/#")
if [ "$(echo "$BOOTPINS" | grep -c .)" != "$(echo $BOOTFILES | wc -w)" ] || ! echo "$BOOTPINS" | sha256sum -c >/dev/null 2>&1; then
    stock "boot files do not match their pins"
fi
echo "$PINS" > "$RUN/pins"


setsid sh "$RUN/boot.sh" "$DIR" "$FW" < /dev/null >> "$STATE/boot.log" 2>&1 &
exit 0
